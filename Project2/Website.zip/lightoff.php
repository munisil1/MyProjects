<?php
	system("python /var/www/html/lightoff.py");
?>
