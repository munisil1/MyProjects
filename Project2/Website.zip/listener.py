#!/usr/bin/env python

import serial
import time
import subprocess

while 1:
    dev = subprocess.check_output('ls ../../../dev/ttyACM*', shell = True)
    ser = serial.Serial(dev.strip(), 9600) #open serial port
    reading = ser.readline() #read from serial
    reading = reading.strip() #strip newline
    if reading != '-100' and reading != '-200' and reading != '-300' and reading != '-400' and reading != 'tripped': #if not special values, then it's a temperature value
        ft = open('temp_info.txt', 'w') #open temp_info.txt to store temperature values from arduino
        ft.write(reading) #write temperature value
        ft.close()
    elif reading == '-100':
        fs = open('security_status.txt', 'w') #open security_status.txt to store current status of home security (ON/OFF)
        fs.write("ON") #write current security status to "ON"
        fs.close()
    elif reading == '-200':
        fs = open('security_status.txt', 'w') #open security_status.txt to store current status of home security (ON/OFF)
        fs.write("OFF") #write current security status to "OFF"
        fs.close()
    elif reading == '-300':
        fl = open('light_status.txt', 'w') #open light_status.txt to store current light status in home (ON/OFF)
        fl.write("ON") #write current light status to "ON"
        fl.close()
    elif reading == '-400':
        fl = open('light_status.txt', 'w') #open light_status.txt to store current light status in home (ON/OFF)
        fl.write("OFF") #write current light status to "OFF"
        fl.close()
    elif reading == 'tripped':
        ftr = open('tripped_status.txt', 'w') #open tripped_status.txt to store time of most recent breach
        ftr.write(time.strftime("%a, %d %b %Y %H:%M:%S")) #write time of most recent breach
        ftr.close()
    
    print reading #for debugging
