<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <link rel="stylesheet" type="text/css" href="style_main.css">
        <script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('#lightON').click(function() {
                    var req = new XMLHttpRequest();
                    req.open("GET", "lighton.php");
                    req.onreadystatechange=function() {
                        if (req.readyState == 4) {
                            if (req.status == 200) {
                            } else {
                                alert("HTTP ERROR");
                            }
                        }
                    }
                    req.send();
                });
                $('#lightOFF').click(function() {
                    var req = new XMLHttpRequest();
                    req.open("GET", "lightoff.php");
                    req.onreadystatechange=function() {
                        if (req.readyState == 4) {
                            if (req.status == 200) {
                            } else {
                                alert("HTTP ERROR");
                            }
                        }
                    }
                    req.send();
                });
                $('#securityOFF').click(function() {
                    var req = new XMLHttpRequest();
                    req.open("GET", "securityoff.php");
                    req.onreadystatechange=function() {
                        if (req.readyState == 4) {
                            if (req.status == 200) {
                            } else {
                                alert("HTTP ERROR");
                            }
                        }
                    }
                    req.send();
                });
                $('#securityON').click(function() {
                    var req = new XMLHttpRequest();
                    req.open("GET", "securityon.php");
                    req.onreadystatechange=function() {
                        if (req.readyState == 4) {
                            if (req.status == 200) {
                            } else {
                                alert("HTTP ERROR");
                            }
                        }
                    }
                    req.send();
                });
            });
        </script>
        <!--AJAX scripts used in displaying real-time data on the website-->
        <script>
            function loadTemp() {
              var xhttp;
              if (window.XMLHttpRequest) {
              // code for modern browsers
              xhttp = new XMLHttpRequest();
              } else {
              // code for IE6, IE5
              xhttp = new ActiveXObject("Microsoft.XMLHTTP");
              }
              xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                  document.getElementById("temp").innerHTML = xhttp.responseText;
                }
              };
              xhttp.open("GET", "temp_info.txt", true);
              xhttp.send();
            }
        </script>
		<script>
            function loadSec() {
              var xhttp;
              if (window.XMLHttpRequest) {
              // code for modern browsers
              xhttp = new XMLHttpRequest();
              } else {
              // code for IE6, IE5
              xhttp = new ActiveXObject("Microsoft.XMLHTTP");
              }
              xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                  document.getElementById("securityStatus").innerHTML = xhttp.responseText;
                }
              };
              xhttp.open("GET", "security_status.txt", true);
              xhttp.send();
            }
        </script>
		<script>
            function loadLight() {
              var xhttp;
              if (window.XMLHttpRequest) {
              // code for modern browsers
              xhttp = new XMLHttpRequest();
              } else {
              // code for IE6, IE5
              xhttp = new ActiveXObject("Microsoft.XMLHTTP");
              }
              xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                  document.getElementById("lightStatus").innerHTML = xhttp.responseText;
                }
              };
              xhttp.open("GET", "light_status.txt", true);
              xhttp.send();
            }
        </script>
        <script>
            function loadBreach() {
              var xhttp;
              if (window.XMLHttpRequest) {
              // code for modern browsers
              xhttp = new XMLHttpRequest();
              } else {
              // code for IE6, IE5
              xhttp = new ActiveXObject("Microsoft.XMLHTTP");
              }
              xhttp.onreadystatechange = function() {
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                  document.getElementById("breachTime").innerHTML = xhttp.responseText;
                }
              };
              xhttp.open("GET", "tripped_status.txt", true);
              xhttp.send();
            }
        </script>
        <script>
            function runListener() {
              var req = new XMLHttpRequest();
              req.open("GET", "listener.php");
                    req.onreadystatechange=function() {
                        if (req.readyState == 4) {
                            if (req.status == 200) {
                            } else {
                                alert("HTTP ERROR");
                            }
                        }
                    }
              req.send();
            }
        </script>
    </head>
    <body onload="setInterval(loadTemp, 1000); setInterval(loadSec, 1000); setInterval(loadLight, 1000); setInterval(loadBreach, 1000)">
        <div id="outermost">
            <div>
                <h2 id="title" class="text-center">Home Security + Control</h2>
                <h6 class="text-center">ELEC 291 Project #2</h6>
                <h6 class="text-center">Group #18</h6>
                <div class="text-center clockBox">
                    <iframe src="http://onlinehtmltools.com/clocks/digital-clock/clock3/" name="iframe985426" width="170px" height="100px" scrolling="No" frameborder="0" align="center"></iframe><br/>
                </div>
            </div>
            <div class="row">
                <div id="stream" class="col-sm-6">
                    <iframe src="http://172.20.10.5:8082/" style="border: 5px solid black;" width="362" height="299"></iframe><br/>
                </div>
                <div id="infoBox" class="col-sm-6">
                    <p>Temperature (&#8451;): </p>
                    <p class="displayFont" id="temp"></p>
                    <p>Light Status: </p>
                    <p class="displayFont" id="lightStatus"></p>
                    <p>Security Status: </p>
                    <p class="displayFont" id="securityStatus"></p>
                    <p>Time of most recent breach: </p>
                    <p class="displayFont" id="breachTime"></p>
                </div>
            </div>
            <div class="row">
                <div class="sendBox col-sm-6 text-center">
                    <p>House Settings</p>
                    <button type="button" class="btn btn-success" id="lightON">LIGHT ON</button>
                    <button type="button" class="btn btn-danger" id="lightOFF">LIGHT OFF</button>
                </div> 
                <div class="receiveBox col-sm-6 text-center">
                    <p>Security Settings</p>
                    <button type="button" class="btn btn-success" id="securityON">SECURITY ON</button>
                    <button type="button" class="btn btn-danger" id="securityOFF">SECURITY OFF</button>
                </div>
            </div>
        </div>
    </body>
</html>
