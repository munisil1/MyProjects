<?php
    system("python /var/www/html/securityoff.py");
?>