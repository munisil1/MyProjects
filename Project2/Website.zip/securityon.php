<?php
	system("python /var/www/html/securityon.py");
?>