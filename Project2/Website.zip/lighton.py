#!/usr/bin/env python

import serial
import time
import subprocess

try:
    print "Searching for Arduino..."
    dev = subprocess.check_output('ls ../../../dev/ttyACM*', shell = True)
except:
    print "Check if Arduino is connected."
    exit(1)
print dev

try:
    print "Trying to open serial port..."
    ser = serial.Serial(dev.strip(), 9600)
    time.sleep(2) #allow time for serial to open
    ser.write('2')
    print "Successfully connected to serial port."
except:
    print "Cannot open serial port."
